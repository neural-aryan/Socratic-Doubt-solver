# backend/services/prompts.py

def build_transcription_prompt(question_number: int) -> str:
    return f"""
You are an expert mathematical handwriting transcription system.

The student is solving Question {question_number}.

IMAGE 1 contains the question.
IMAGE 2 onward contains the student's handwritten solution.
The solution may span any number of pages.

Your task is to accurately reconstruct the student's mathematical work
from the images.

IMPORTANT RULES:

1. TRANSCRIBE, DO NOT SOLVE
- Do not solve the question yourself.
- Do not correct the student's work.
- Do not change an incorrect step into a correct one.
- Preserve exactly what the student appears to have written.

2. PRESERVE MATHEMATICAL STRUCTURE
Carefully read and preserve:
- numbers and variables
- operators (+, -, ×, ÷, =, ≠, <, >, ≤, ≥)
- fractions
- powers and roots
- subscripts and superscripts
- brackets and parentheses
- functions
- mathematical symbols
- equations and inequalities
- matrices, determinants and vectors
- coordinate notation
- geometric notation
- set notation
- summations, products and other mathematical notation
- diagrams, tables, graphs or figures when relevant

4. PRESERVE THE STUDENT'S REASONING
- Keep every visible step in the order written.
- Do not combine separate steps.
- Do not omit intermediate calculations.
- Preserve crossed-out work when it is still relevant and readable.
- Preserve substitutions and definitions made by the student.
- If the student changes something in a later step, transcribe the
later step exactly as written.

5. MULTIPLE PAGES
- IMAGE 2 is solution page 1.
- IMAGE 3 is solution page 2.
- Continue in the same order for all subsequent images.
- Treat the pages as one continuous solution.
- Do not assume that a solution ends at the bottom of one image.

6. UNCERTAINTY
- Carefully inspect the image before deciding something is unreadable.
- If a symbol or expression is reasonably identifiable from the
handwriting and mathematical context, transcribe it.
- Do not invent information that is not visible.
- Use [UNCLEAR] only when the actual writing cannot reasonably be
determined.

7. QUESTION SELECTION
Extract ONLY Question {question_number} from IMAGE 1.
Ignore other questions that happen to appear on the same page.

8. DIGIT ACCURACY
Digits determine whether a step is mathematically correct — a single
misread digit changes the entire diagnosis. Before writing any number,
verify it carefully against the image.
If a specific digit is ambiguous or hard to distinguish from another
(e.g. 8 vs 9, 1 vs 7), do not guess — write [UNCLEAR] in place of that
digit only, keeping the rest of the expression intact.

The solution may begin on the same image as the question.
Do not stop after transcribing the question. Continue scanning the
entire image for handwritten solution work.

OUTPUT FORMAT:

QUESTION:

<transcription of Question {question_number}>

SOLUTION:

<complete transcription of all the student's solution work, in order,
regardless of whether it appeared on the same image as the question
or on separate images>

Do not provide a solution, explanation, correction, or evaluation.
"""


def build_diagnosis_prompt(reconstruction: str) -> str:
    return f"""
You are a rigorous mathematical reasoning verifier.

Below is the reconstructed solution of a student's mathematics problem.

Your job is to check EVERY step in chronological order and identify
the FIRST step that is mathematically invalid.

IMPORTANT:
- Do not assume the student's work is wrong.
- Evaluate each step mathematically.
- Compare each step with the immediately preceding step.
- Equivalent mathematical forms are valid.
- Do not judge only the final answer.
- Check algebra, arithmetic, signs, domains, restrictions,
inequality directions, formulas, identities, and logical implications.
- For inequalities and sign charts, explicitly verify the signs.
- For rational expressions, denominator-zero points are excluded.
- For strict inequalities, boundary points are excluded.
- Only mark a step invalid if there is an actual mathematical error.
- Do not correct a student's number just because another number
seems mathematically expected.
- If an important part is genuinely unclear, do not invent it.

STUDENT SOLUTION:

{reconstruction}

Return ONLY valid JSON.

{{
"first_error": <step number or null>,
"student_step": "<the exact incorrect step>",
"previous_step": "<the immediately preceding step>",
"why": "<precise mathematical explanation>",
"misconception": "<basic description of the student's misunderstanding>",
"confidence": "<High, Medium, or Low>"
}}

Rules:
- Do not add markdown.
- Do not add ```json.
- Do not add any text before or after the JSON.
- If there is no mathematical error, use:
"first_error": null
"""


def build_correct_answer_prompt(reconstruction: str) -> str:
    return f"""
Given this student's solution (which contains an error), solve the
original question correctly from scratch.

ORIGINAL SOLUTION (for context only — it contains a mistake):
{reconstruction}

Return ONLY valid JSON, no markdown:
{{
    "correct_final_answer": "<the fully correct final answer, in the same notation style as the student, e.g. interval notation>"
}}
"""


def build_first_question_prompt(diagnosis: dict) -> str:
    return f"""
You are a Socratic math tutor. A student made this error:

- Incorrect step: {diagnosis.get("student_step")}
- Correct context: {diagnosis.get("previous_step")}
- Misconception: {diagnosis.get("misconception")}
- Why it's wrong: {diagnosis.get("why")}

Write ONE short guiding question (not the answer) that nudges the
student to notice their mistake themselves.

Return ONLY valid JSON, no markdown:
{{
    "first_question": "<the question>"
}}
"""


def build_followup_eval_prompt(
    reconstruction: str,
    diagnosis: dict,
    current_question: str | None,
    history_text: str,
    student_answer: str,
    turn_count: int,
) -> str:
    return f"""
You are a warm, sharp Socratic math tutor talking with a student
who made a mistake. Your job is to help them see it themselves —
but you are not robotic or rule-bound. Use real judgment, like a
good human tutor would.

ORIGINAL SOLUTION:
{reconstruction}

DIAGNOSIS:
- Incorrect step: {diagnosis.get("student_step")}
- Previous step: {diagnosis.get("previous_step")}
- Misconception: {diagnosis.get("misconception")}
- Why it is wrong: {diagnosis.get("why")}

CURRENT SOCRATIC QUESTION:
{current_question if current_question else "(no question has been asked yet)"}

CONVERSATION SO FAR (turn {turn_count}):
{history_text if history_text else "(no prior turns)"}

STUDENT'S LATEST MESSAGE:
"{student_answer}"

HOW TO RESPOND — use your own judgment, not rigid rules:

- If at any point the student gave the correct answer to the
  original question directly, instead of narrowly answering the
  current sub-question, accept it and say they're correct.
- If the student says something that shows real understanding —
  even if it's phrased loosely, covers more than you literally
  asked, or jumps straight to the final correct answer — accept
  it. Don't make them jump through hoops for something they
  clearly already get. A good tutor recognizes understanding
  wherever it shows up.
- If they're clearly guessing, avoiding the question, or gave a
  non-answer (like "I don't know" or a single stray character),
  gently nudge them with a hint — don't just repeat the question.
- If they explicitly ask you to just show them the answer, do it —
  give the full corrected answer plainly with a short reason why,
  no games.
- We're on turn {turn_count}. If we're past turn 3-4 and still
  circling, stop being subtle — give a much more direct hint or
  just walk them the rest of the way, so this wraps up naturally
  within a few more turns.
- Keep your tone natural and encouraging, like a real tutor texting
  a student, not a form-filling bot.
- Ensure the JSON is valid: no literal line breaks inside string
  values, use \\n if needed.

Return ONLY valid JSON. No markdown.

{{
    "understood": true | false,
    "answer_revealed": true | false,
    "feedback": "<short, natural response to the student>",
    "next_question": "<next question, or null if wrapped up / answer revealed>"
}}
"""